package com.microservice.test.distributor.dto;

import lombok.Data;
import lombok.Value;

@Data
@Value
public class PurchaseOrderDto {
	private String purchaseOrderName;
    private Double purchaseOrerQuantity;
    private Double purchaseOrderAmount;
    private String purchaseOrderDate;
}
