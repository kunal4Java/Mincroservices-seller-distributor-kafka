package com.microservice.test.distributor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.microservice.test.distributor.domain.PurchaseOrder;

@Repository
public interface DistributorOrderRepository extends JpaRepository<PurchaseOrder, Long> {
}
