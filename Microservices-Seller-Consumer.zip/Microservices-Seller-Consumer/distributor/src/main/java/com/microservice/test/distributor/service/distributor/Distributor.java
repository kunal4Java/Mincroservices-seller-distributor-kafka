package com.microservice.test.distributor.service.distributor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservice.test.distributor.domain.PurchaseOrder;
import com.microservice.test.distributor.dto.PurchaseOrderDto;
import com.microservice.test.distributor.service.DistributorOrderService;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class Distributor {

    private static final String orderTopic = "${topic.name}";

    private final ObjectMapper objectMapper;
    private final ModelMapper modelMapper;
    private final DistributorOrderService distributorOrderService;

    @Autowired
    public Distributor(ObjectMapper objectMapper, ModelMapper modelMapper, DistributorOrderService purchaseOrderService) {
        this.objectMapper = objectMapper;
        this.modelMapper = modelMapper;
        this.distributorOrderService = purchaseOrderService;
    }

    @KafkaListener(topics = orderTopic)
    public void consumeMessage(String message) throws JsonProcessingException {
        log.info("Purchase order received"+ message);

        PurchaseOrderDto purchaseOrderDto = objectMapper.readValue(message, PurchaseOrderDto.class);
        PurchaseOrder purchaseOrder = modelMapper.map(purchaseOrderDto, PurchaseOrder.class);

        distributorOrderService.persistPurchaseOrder(purchaseOrder);
    }

}
