package com.microservice.test.distributor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.test.distributor.domain.PurchaseOrder;
import com.microservice.test.distributor.repository.DistributorOrderRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DistributorOrderService {

    private final DistributorOrderRepository purchaseOrderRepository;

    @Autowired
    public DistributorOrderService(DistributorOrderRepository purchaseOrderRepository) {
        this.purchaseOrderRepository = purchaseOrderRepository;
    }

    public void persistPurchaseOrder(PurchaseOrder purchaseOrder) {
        PurchaseOrder persistedPurchaseOrder = purchaseOrderRepository.save(purchaseOrder);
        log.info("Purchase order save to database", persistedPurchaseOrder);
    }

}
