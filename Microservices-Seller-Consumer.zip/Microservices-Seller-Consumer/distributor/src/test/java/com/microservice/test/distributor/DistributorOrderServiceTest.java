package com.microservice.test.distributor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.microservice.test.distributor.domain.PurchaseOrder;
import com.microservice.test.distributor.repository.DistributorOrderRepository;
import com.microservice.test.distributor.service.DistributorOrderService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DistributorOrderServiceTest{

	
	@InjectMocks
	DistributorOrderService distributorOrderService;
	
	@Mock
	DistributorOrderRepository purchaseOrderRepository;
	
	
	PurchaseOrder purchaseData = PurchaseOrder.builder().purchaseOrderName("unitTest_Consume")
			.purchaseOrderAmount(3000.00)
			.purchaseOrerQuantity(10.00)
			.purchaseOrderDate("16-March-2023")
			.build();
	
	@Test
	public void persistPurchaseOrderTest() {
		
		Mockito.when(purchaseOrderRepository.save(purchaseData)).thenReturn(purchaseData);
		distributorOrderService.persistPurchaseOrder(purchaseData);
	}
}
