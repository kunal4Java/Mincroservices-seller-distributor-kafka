package com.microservice.test.distributor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservice.test.distributor.domain.PurchaseOrder;
import com.microservice.test.distributor.dto.PurchaseOrderDto;
import com.microservice.test.distributor.service.DistributorOrderService;
import com.microservice.test.distributor.service.distributor.Distributor;


@RunWith(SpringRunner.class)
@SpringBootTest
public class DistributorTest{

	
	DistributorOrderService dis;
	
	@InjectMocks
	private Distributor distributor;
	
	@Mock
	private DistributorOrderService distributorOrderService;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
    private ModelMapper modelMapper;
	
	
	PurchaseOrder purchaseData = PurchaseOrder.builder().purchaseOrderName("unitTest_distributor")
			.purchaseOrderAmount(1000.00)
			.purchaseOrerQuantity(10.00)
			.purchaseOrderDate("16-March-2023")
			.build();
	PurchaseOrderDto purchaseOrderDTO = null;
	
	@Test
	public void consumeMessageTest() throws Exception{ 
		
		distributor = new Distributor(objectMapper, modelMapper, distributorOrderService);
		
		Mockito.when(objectMapper.readValue("", PurchaseOrderDto.class)).thenReturn(purchaseOrderDTO);
		Mockito.when(modelMapper.map(purchaseOrderDTO, PurchaseOrder.class)).thenReturn(purchaseData);
		
		Mockito.doNothing().when(distributorOrderService).persistPurchaseOrder(purchaseData);
		
		distributor.consumeMessage("");
		
	}
}
