package com.microservice.test.seller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.microservice.test.seller.domain.PurchaseData;
import com.microservice.test.seller.service.PurchaseDataService;
import com.microservice.test.seller.service.kafka.PurchaseProducer;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PurchaseDataServiceTest {
	

	@Mock
	PurchaseProducer purchaseProducer;
	
	@InjectMocks
	PurchaseDataService  purchaseDataService;
	
	PurchaseData purchaseData = PurchaseData.builder().purchaseOrderName("unitTest_purchaseData")
			.purchaseOrderAmount(2000.00)
			.purchaseOrerQuantity(20.00)
			.purchaseOrderDate("15-March-2023")
			.build();
	
	@Test
	public void createPurchaseOrderTest() throws Exception{
	

		Mockito.when(purchaseProducer.sendMessage(purchaseData)).thenReturn("");
	
		purchaseDataService.createPurchaseOrder(purchaseData);
		
	}

}
