package com.microservice.test.seller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.concurrent.ListenableFuture;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservice.test.seller.domain.PurchaseData;
import com.microservice.test.seller.service.kafka.PurchaseProducer;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PurchaseProducerTest {

	@InjectMocks
	private PurchaseProducer purchaseProducer;

	@Mock
	private KafkaTemplate<String, String> kafkaTemplate;

	@Mock
	ObjectMapper objectMapper;

	private ListenableFuture<SendResult<String, String>> future = null;

	PurchaseData purchaseData = PurchaseData.builder().purchaseOrderName("unitTest_purchaseProducer")
			.purchaseOrderAmount(2000.00).purchaseOrerQuantity(20.00).purchaseOrderDate("15-March-2023").build();

	@Test
	public void sendMessageTest() throws Exception {

		Mockito.when(objectMapper.writeValueAsString(purchaseData)).thenReturn("");
		Mockito.when(kafkaTemplate.send("", "")).thenReturn(future);
		purchaseProducer.sendMessage(purchaseData);

	}
}
