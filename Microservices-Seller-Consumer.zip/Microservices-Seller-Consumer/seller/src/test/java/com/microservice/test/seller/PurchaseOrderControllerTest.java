package com.microservice.test.seller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.WebApplicationContext;

import com.microservice.test.seller.controller.PurchaseOrderController;
import com.microservice.test.seller.domain.PurchaseData;
import com.microservice.test.seller.service.PurchaseDataService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class PurchaseOrderControllerTest{

	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@InjectMocks
	private PurchaseOrderController purchaseOrderController;
	
	@Mock
	private PurchaseDataService purchaseDataService;
	
	/*@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	*/
	PurchaseData purchaseData = PurchaseData.builder().purchaseOrderName("unitTest_purchaseOrderController")
			.purchaseOrderAmount(1000.00)
			.purchaseOrerQuantity(10.00)
			.purchaseOrderDate("14-March-2023")
			.build();

	@Test
	public void sendOrder() throws Exception {
		
		
		Mockito.when(purchaseDataService.createPurchaseOrder(purchaseData)).thenReturn("Purchase Order Sent To Kafka");
		
		purchaseOrderController.createPurchaseOrder(purchaseData);
		
		
		
		/*MvcResult mvcResult = mockMvc.perform(post("/order")
		.content(objectMapper.writeValueAsString(purchaseData))
		.contentType(MediaType.APPLICATION_JSON)
		.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().is(200))
		.andReturn();

		log.info("Mock result object -->",mvcResult);*/
	}
	
}
