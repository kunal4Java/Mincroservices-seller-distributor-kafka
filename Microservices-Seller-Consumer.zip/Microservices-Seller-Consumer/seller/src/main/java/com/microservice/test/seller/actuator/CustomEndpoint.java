package com.microservice.test.seller.actuator;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id="custom-endpoint1")
public class CustomEndpoint{
    
    @ReadOperation
    @Bean
    public String readEndpoint() {
        return "This is a custom end point for demo purpose";
    }

}