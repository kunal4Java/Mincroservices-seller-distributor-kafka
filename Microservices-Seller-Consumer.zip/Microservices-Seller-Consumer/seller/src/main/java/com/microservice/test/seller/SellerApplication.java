package com.microservice.test.seller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SellerApplication {

	private static final Logger logger = LoggerFactory.getLogger(SellerApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SellerApplication.class, args);
		logger.info("Running Seller Application...");
	}

}
