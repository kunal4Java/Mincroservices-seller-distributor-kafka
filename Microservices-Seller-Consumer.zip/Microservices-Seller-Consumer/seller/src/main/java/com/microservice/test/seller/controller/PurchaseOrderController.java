package com.microservice.test.seller.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.microservice.test.seller.domain.PurchaseData;
import com.microservice.test.seller.service.PurchaseDataService;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/order")
public class PurchaseOrderController {

    private final PurchaseDataService purchaseOrderService;
    
    @Autowired
    public PurchaseOrderController(PurchaseDataService purchaseOrderService) {
        this.purchaseOrderService = purchaseOrderService;
    }

    @PostMapping
    public String createPurchaseOrder(@RequestBody PurchaseData purchaseOrder) throws JsonProcessingException {
        log.info("create purchase order request received");
        return purchaseOrderService.createPurchaseOrder(purchaseOrder);
    }
}
