package com.microservice.test.seller.service.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microservice.test.seller.domain.PurchaseData;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PurchaseProducer {

    @Value("${topic.name}")
    private String orderTopic;

    private final ObjectMapper objectMapper;
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public PurchaseProducer(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }

    public String sendMessage(PurchaseData purchaseOrder) throws JsonProcessingException {
        String orderAsMessage = objectMapper.writeValueAsString(purchaseOrder);
        kafkaTemplate.send(orderTopic, orderAsMessage);

        log.info("Purchase order sent ", orderAsMessage);

        return "Purchase order sent to Kafka";
    }
}
