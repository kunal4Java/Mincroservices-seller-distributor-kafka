package com.microservice.test.seller.domain;

import lombok.Builder;
import lombok.Data;
import lombok.Value;

@Data
@Value
@Builder
public class PurchaseData {
    private String purchaseOrderName;
    private Double purchaseOrerQuantity;
    private Double purchaseOrderAmount;
    private String purchaseOrderDate;
    
}
