package com.microservice.test.seller.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.microservice.test.seller.domain.PurchaseData;
import com.microservice.test.seller.service.kafka.PurchaseProducer;

@Service
public class PurchaseDataService {

    private final PurchaseProducer producer;

    @Autowired
    public PurchaseDataService(PurchaseProducer producer) {
        this.producer = producer;
    }

    public String createPurchaseOrder(PurchaseData purchaseOrder) throws JsonProcessingException {
        return producer.sendMessage(purchaseOrder);
    }
}
